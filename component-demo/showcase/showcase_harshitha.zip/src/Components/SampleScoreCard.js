import React, { Component } from "react";
import Hero from "@pxblue/react-components/core/Hero";
import HeroBanner from "@pxblue/react-components/core/HeroBanner";
import InfoListItem from "@pxblue/react-components/core/InfoListItem";
import ScoreCard from "@pxblue/react-components/core/ScoreCard";
import { withStyles } from "@material-ui/core/styles";
import './SampleScoreCard.css'

import {
  List,
  Card,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Grid
} from "@material-ui/core";
import { ChevronRight, MoreVert } from "@material-ui/icons";
import * as Colors from "@pxblue/colors";
import {
  GasCylinder,
  Temp,
  Flow,
  Moisture as Humidity
} from "@pxblue/icons-mui";
import Button from "@material-ui/core/Button";
import {
  CloudCircle,
  NotificationsActive,
  Notifications,
  Info
} from "@material-ui/icons";
import top from "../topology_40.png";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import { makeStyles } from "@material-ui/core/styles";



const useStyles = theme => ({
  root: {
    // justifyContent: "space-around",
    // overflow: "hidden",
    margin: 10
  },
  gridList: {
    width: 500,
    height: 450
  },

});

class SampleScoreCard extends Component {
  render() {
    const classes = useStyles();

    const data = this.props.scoreCardData;


    console.log(data);
    return (
      <Grid container className='score-card-grid'>
        <div style={{ display: 'flex', maxWidth: '1200px', flexWrap: 'wrap', margin:' 0 auto' }}>
          {data.map((scoreCardData, i) => {
        
            const {title,alarmCount,subtitle,deviceCount,eventCount,commStatus} = scoreCardData;
            
		const Icons = {
			temperature: { 
				tempIcon:<Temp fontSize={'inherit'} htmlColor={Colors.black[500]} />,
				unit: '°F'
			},
			flow: {
				flowIcon: <Flow fontSize={'inherit'} htmlColor={Colors.black[500]} />,
				unit: 'KSCFH'
			},
			humidity: {
				HumidityIcon: 	<Humidity fontSize={'inherit'} htmlColor={eventCount > 0 ? Colors.blue[500] : Colors.black[500]}/>,
				unit: '%'
			},
			gasCylinder: {
				GasCylinderIcon: <GasCylinder fontSize={'inherit'} htmlColor={eventCount > 0 ? Colors.blue[500] : Colors.black[500]}/>,
				unit: 'KSCF'
      }	,
      cloud:{
          cloudIcon:<CloudCircle color={"inherit"} />
      },
      Info:{
          infoIcon:<Info color={"inherit"} />
      },
      Notification:{
          notificationInActive:  <Notifications
          style={{ color: "grey" }}
        ></Notifications>,
        notificationActive: <NotificationsActive
        style={{ color: "red" }}
      ></NotificationsActive>
      }
    }
    const values = Object.keys(scoreCardData.values);
    console.log(values[values[0]]);
            return (
              <Grid  item style={{padding:10}} xs={12} sm={6} md={6} lg={4} xl={4}  cols={3} >
                <ScoreCard
                  style={{ maxWidth: 400 }}
                  headerColor={
                    alarmCount > 0
                      ? Colors.blue[500]
                      : Colors.red[500]
                  }
                  headerBackgroundImage={top}
                  headerTitle={title}
                  headerSubtitle={subtitle}
                  headerInfo={deviceCount + " Devices"}
                  headerFontColor={Colors.white[50]}
                  actionItems={[
                    <MoreVert onClick={() => alert("something did")} />
                  ]}
                  badge={
                    <HeroBanner >
                      {
                        <Hero
                          icon={
                            values[0] === "temperature" ? (
                            Icons.temperature.tempIcon
                            ) : (
                              Icons.flow.flowIcon
                            )
                          }                        
                          label={values[0]}
                          iconSize={48}
                          value={values[values[0]]}
                          units={values[0] === "temperature" ? "°F" : "KSCFH"}
                          fontSize={"normal"}
                        />
                      }
                      <Hero
                        icon={
                          values[1] === "humidity" ? (
                            <Humidity
                              fontSize={"inherit"}
                              htmlColor={Colors.blue[200]}
                            />
                          ) : (
                            <GasCylinder
                              fontSize={"inherit"}
                              htmlColor={Colors.blue[300]}
                            />
                          )
                        }
                        label={values[1]}
                        value={values[values[1]]}
                        units={values[0] === "temperature" ? "%" : "KSCF"}
                        iconSize={48}
                        fontSize={"normal"}
                      />
                    </HeroBanner>
                  }
                  badgeOffset={0}
                  actionRow={
                    <List style={{ margin: 0 }}>
                      <ListItem>
                        <ListItemText primary="View Location" />
                        <ListItemSecondaryAction>
                          {" "}
                          <ChevronRight />{" "}
                        </ListItemSecondaryAction>
                      </ListItem>
                    </List>
                  }
                >
                  <List style={{ padding: "16px 0" }}>
                    <InfoListItem
                      dense
                      style={{ height: 36 }}
                      fontColor={
                        scoreCardData.alarmCount
                          ? Colors.red[500]
                          : Colors.black[100]
                      }
                      iconColor={
                        scoreCardData.alarmCount
                          ? Colors.red[500]
                          : Colors.black[100]
                      }
                      title={scoreCardData.alarmCount + " Alarm"}
                      icon={
                        scoreCardData.alarmCount <= 0 ? (
                          <Notifications
                            style={{ color: "grey" }}
                          ></Notifications>
                        ) : (
                          <NotificationsActive
                            style={{ color: "red" }}
                          ></NotificationsActive>
                        )
                      }
                    />
                    <InfoListItem
                      dense
                      style={{ height: 36 }}
                      fontColor={
                        eventCount
                          ? Colors.red[500]
                          : Colors.black[100]
                      }
                      iconColor={
                        eventCount
                          ? Colors.red[500]
                          : Colors.black[100]
                      }
                      title={eventCount + " Event"}
                      icon={<Info color={"inherit"} />}
                    />
                    <InfoListItem
                      dense
                      style={{ height: 36 }}
                      title={commStatus}
                      icon={<CloudCircle color={"inherit"} />}
                    />
                  </List>
                </ScoreCard>
              </Grid>
            );
          })}
      </div>
      </Grid>
    );
  }
}
export default withStyles(useStyles)(SampleScoreCard);
