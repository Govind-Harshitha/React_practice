import React, { Component } from "react";
import { Grid } from "@material-ui/core";
import SampleData from "./shared/SampleData.json";
import SampleScoreCard from "./Components/SampleScoreCard.js";

class App extends Component {
  render() {
    return (
    //   <Grid container>
        <SampleScoreCard scoreCardData={SampleData} />
    //   </Grid>
    );
  }
}

export default App;
